const mysql = require("mysql2");

// Create the connection pool.
const conn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "manager",
  database: "AgricomDB",
});

module.exports = conn;
