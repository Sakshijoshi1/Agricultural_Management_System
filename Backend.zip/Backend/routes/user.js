const express = require("express");
const router = express.Router();
const crypto = require("crypto-js");
const conn = require("../db");
const jwt =require('jsonwebtoken');
const config = require('config');

//register user
router.post("/register", (request, response) => {
  const {username,email,password,contact,address} = request.body;

  const statement = `INSERT INTO user(username, email, password,contact,address) VALUES(?,?,?,?,?)`;

  conn.execute(statement, [username, email,password,contact,address], (err, result) => {
    if (err) response.send(err.message);
    else response.send("registered successfully...");
  });
});


// router.post("/register", (request, response) => {
//   const {
//     username = null,
//     email = null,
//     password = null,
//     contact = null,
//     address = null
//   } = request.body;

//   // Log the registration data
//   console.log('Registration Data:', { username, email, password, contact, address });

//   const statement = `INSERT INTO user
//   (username, email, password, contact, address) VALUES(?,?,?,?,?)`;

//   conn.execute(statement, [username, email, password, contact, address], (err, result) => {
//     if (err) {
//       console.error('SQL Error:', err);
//       response.send(err.message);
//     } else {
//       response.send("Registered successfully...");
//     }
//   });
// });



//login user
router.post("/login", (request, response) => {
  const { email, password } = request.body;

  const statement = `SELECT
      user_id , username, email, password
      FROM user
      WHERE email =? AND password =?`;

  conn.execute(statement, [email, password], (err, user) => {
    if (err) response.send(err.message);
    else {
      if (user.length == 0) response.status(404).send("No user found");
      else {
        const { username, email } = user[0];
        const payload={username, email};
       // var key = config.get("jwtkey");
       var key = config.get("jwtkey")
       console.log("Login "+key)
        const token=jwt.sign(payload,key);

        response.json({
          status: "success",
          data: {
            username,
            email,
            token,
          },
        });
      }
    }
  });
});

// fetch all products
router.get("/product", (request, response) => {
  const statement = `SELECT * FROM Product`;
  conn.execute(statement, (err, rows) => {
    if (err) response.send(err.message);
    else if (rows.length === 0) response.send("no Product found");
    else response.json({ status: "success", data: rows });
  });
});


// fetch product by id
router.get("/product/:product_id", (request, response) => {
  const { product_id } = request.params; 
  const statement = `SELECT * FROM Product WHERE product_id = ?`;

  conn.execute(statement, [product_id], (err, rows) => {
    if (err) {
      response.status(500).json({ error: err.message });
    } else if (rows.length === 0) {
      response.status(404).json({ message: "No product found" });
    } else {
      response.status(200).json({ status: "success", data: rows[0] });
    }
  });
});

//fetch all cart 

router.get("/cart", (request, response) => {
  const statement = `SELECT * FROM Cart`;
  conn.execute(statement, (err, rows) => {
    if (err) response.send(err.message);
    else if (rows.length === 0) response.send("no Cart found");
    else response.json({ status: "success", data: rows });
  });
});

// delete cart by id
// router.delete("/cart/:cart_id", (request, response) => {
//   const { cart_id } = request.params;
//   const statement = `DELETE FROM cart WHERE cart_id = ?`;
//   conn.execute(statement, [cart_id], (err, result) => {
//     if (err) {
//       response.send(err.message);
//     } else if (result.affectedRows === 0) {
//       response.send("Cart not found");
//     } else {
//       response.json({ status: "success", message: "Cart deleted" });
//     }
//   });
// });


router.delete("/cart/:id", (request, response) => {
  const cart_id = request.params.id;

  // Log the cart_id to debug
  console.log('Cart ID:', cart_id);

  // Check if cart_id is defined
  if (!cart_id) {
    return response.status(400).json({ error: "Missing cart_id parameter" });
  }

  const statement = `DELETE FROM cart WHERE cart_id = ?`;

  conn.execute(statement, [cart_id], (err, result) => {
    if (err) {
      console.error('SQL Error:', err);
      response.status(500).send(err.message);
    } else if (result.affectedRows === 0) {
      response.status(404).send("Cart not found");
    } else {
      console.log(`Item with cart_id: ${cart_id} deleted successfully`);
      response.json({ status: "success", message: "Cart deleted" });
    }
  });
});


// place Product order
router.post("/place-order", (request, response) => {
  const { userId, productId } = request.body;

  
  console.log("Request Body:", request.body);

  
  if (!userId || !productId) {
    return response.status(400).json({ error: "Missing userId or productId" });
  }

  const statement = `
    INSERT INTO Cart (user_id, product_id)
    VALUES (?, ?)
  `;

  conn.execute(statement, [userId, productId], (err, result) => {
    if (err) {
      console.error("Database error:", err);
      return response.status(500).json({ error: "Internal server error" });
    }

    response.json({
      status: "success",
      message: "Order placed successfully",
    });
  });
});


// // place Order details
// router.post("/place-orderdetails", (request, response) => {
//   const { userId, total_amount, order_status, created_at } = request.body;

 
//   console.log("Request Body:", request.body);

//   // Validate request body
//   if (!userId || !total_amount || !order_status || !created_at) {
//     return response.status(400).json({ error: "Missing required fields" });
//   }

//   const statement = `
//     INSERT INTO OrderTable (user_id, total_amount, order_status, created_at)
//     VALUES (?, ?, ?, ?)
//   `;

//   conn.execute(statement, [userId, total_amount, order_status, created_at], (err, result) => {
//     if (err) {
//       console.error("Database error:", err); // Log the error for debugging
//       return response.status(500).json({ error: "Internal server error" });
//     }

//     response.json({
//       status: "success",
//       message: "Order placed successfully",
//     });
//   });
// });


// Place Order Details
router.post("/place-orderdetails", (request, response) => {
  const { userId, total_amount, order_status, created_at } = request.body;

  console.log("Request Body:", request.body);

  // // Validate request body
  if (!userId || !total_amount || !order_status || !created_at) {
    return response.status(400).json({ error: "Missing required fields" });
  }

  const statement = `
    INSERT INTO OrderTable (user_id, total_amount, order_status, created_at)
    VALUES (?, ?, ?, ?)
  `;

  conn.query(statement, [userId, total_amount, order_status, created_at], (err, result) => {
    if (err) {
      console.error("Database error:", err); // Log the error for debugging
      return response.status(500).json({ error: "Internal server error" });
    }

    response.json({
      status: "success",
      message: "Order placed successfully",
      order_id: result.insertId // Assuming result.insertId gives you the new order ID
    });
  });
});
//fetch all orderdetails

router.get("/place-orderdetails", (request, response) => {
  const statement = `SELECT * FROM OrderTable`;
  conn.execute(statement, (err, rows) => {
    if (err) response.send(err.message);
    else if (rows.length === 0) response.send("no Cart found");
    else response.json({ status: "success", data: rows });
  });
});


//Place order Items

router.post("/place-orderitems", (request, response) => {
  const { orderId, productId, quantity, price } = request.body;

  // Log the request body for debugging
  console.log("Request Body:", request.body);

  // Validate request body
  if (!orderId || !productId || !quantity || !price) {
    return response.status(400).json({ error: "Missing required fields" });
  }

  const statement = `
    INSERT INTO orderitems (order_id , product_id , quantity, price )
    VALUES (?, ?, ?, ?)
  `;

  conn.execute(statement, [orderId, productId, quantity, price], (err, result) => {
    if (err) {
      console.error("Database error:", err); // Log the error for debugging
      return response.status(500).json({ error: "Internal server error" });
    }

    response.json({
      status: "success",
      message: "OrderItems placed successfully",
    });
  });
});

//fetch all order Items
router.get("/place-orderitems", (request, response) => {
  const statement = `SELECT * FROM  orderitems`;
  conn.execute(statement, (err, rows) => {
    if (err) response.send(err.message);
    else if (rows.length === 0) response.send("no  orderitems found");
    else response.json({ status: "success", data: rows });
  });
});


// fetch all Yojna
router.get("/yojna", (request, response) => {
  const statement = `SELECT * FROM Yojna`;
  conn.execute(statement, (err, rows) => {
    if (err) response.send(err.message);
    else if (rows.length === 0) response.send("no Yojna found");
    else response.json({ status: "success", data: rows });
  });
});
// fetch Yojna by id
router.get("/yojna/:id", (request, response) => {
  const { id } = request.params; // Destructure id from request.params
  const statement = `SELECT * FROM Yojna WHERE id = ?`;

  console.log("Yojna ID:", id); 
  conn.execute(statement, [id], (err, rows) => {
    if (err) {
      console.error("Database error:", err);
      return response.status(500).json({ error: "Internal server error" });
    }
    if (rows.length === 0) {
      return response.status(404).json({ message: "No Yojna found" });
    }
    response.status(200).json({ status: "success", data: rows[0] });
  });
});

router.post('/product/search', (req, res) => {
  const queryText = req.body.queryText;
  const query = `SELECT * FROM product WHERE name LIKE '%${queryText}%'`;
  console.log('Query:', query);
  conn.execute(query, (err, results) => {
    if (err) {
      res.status(500).json({ error: 'An error occurred while searching for products' });
    } else {
      res.json({ data: results });
    }
  });
});

// Registering a contact
router.post("/contacts", (req, res) => {
  
  const { name, email, message } = req.body;
  const statement = `INSERT INTO contacts(name, email, message) VALUES (?, ?, ?)`;

  conn.execute(statement, [name, email, message], (err, result) => {
    if (err) {
      res.status(500).send(err.message); // Set status to 500 for server error
    } else {
      res.status(201).send("Contact added successfully."); // Set status to 201 for created resource
    }
  });
});

// Retrieving all contacts
router.get("/contacts", (req, res) => {
  console.log("Fetching all contacts...");
  const statement = `SELECT * FROM contacts`;

  conn.execute(statement, (err, results) => {
    if (err) res.send(err.message);
    else res.send(results);
  });
});


module.exports = router;
